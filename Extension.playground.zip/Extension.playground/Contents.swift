import UIKit

//Extension
extension Int { //bu satır genişletilmek istenen classı temsil eder.
    func carp(sayi:Int) -> Int {
return self * sayi //burada self genişletilmek istenen class yani Int kısmını temsil ederken sayi alanı da dışarıdan alınan sayıyı temsil eder
        
    }
}
let x = 3.carp(sayi: 5)
print(x)


//Closure

let ifade = { //burada yer alan kod bloğunu temsil eder.
    print ("Merhaba Büşra")
}
ifade() //kod bloğunun içerisinde yer alan ifadeyi bu şekilde aktarırız ve buna closure denir.
